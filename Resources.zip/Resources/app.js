	
	var cc = require('CloudController');
	//Ti.Database.install("db.sqlite", "db");     // installing sqlite db into app
	//var dbController = require('dbController'); // create instance for database controller
	
	
	//var initialized = updateDB(); // function for updating database from api

//if(initialized) {
	var window1 = require('list'); //requiring list information to show on main window
	window1.showInfo();  //show info
//}
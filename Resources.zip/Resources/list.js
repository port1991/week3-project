var url = "https://btc-e.com/api/2/btc_usd/ticker";

function showInfo(){
//2nd step

var xhr = Ti.Network.createHTTPClient({
    onload: function(e) {
        //Ti.API.info("Response: "+this.responseText);
    	var json=JSON.parse(this.responseText);
    	Ti.App.Properties.setObject("BTC-E_INFO", json); // saving the weather api json
    	showInfo(); // calling the function to view information
    	//alert(json.current_observation.station_id);
    },
    onerror: function(e) {
        //Ti.API.debug(e.error);
        showInfo(); // if error then show information if there is old information found
        alert('Network error');
    },
    timeout:10000
});
xhr.open("GET", url);
xhr.send();

//================================================================================================================
//================================================================================================================

    //
	
	var json = Ti.App.Properties.getObject("BTC-E_INFO", null); //getting the object from weather info
	

if(json != null){       //checking if JSON is null or the old data    null means user didn't get info from the internet
		// the main scroll view where all the information will be included
		var windowInfo = Ti.UI.createWindow({
			//showVerticalScrowIndicator : true,
			//backgroundImage: "Halftone-Grunge-Textures.jpg",
			layout : "horizontal",
			fullscreen: true
		});
		
		//===============================//info get          http://jsonviewer.stack.hu/
		//date
		var currentDate = new Date();
		
		var lblYear = Ti.UI.createLabel({
			color: 'white',
			left: 10,
			fontWeight: 'bold',
			text: currentDate.getFullYear() + " " + "/" + " " + currentDate.getMonth() + " " + "/" + " " + currentDate.getDate()  ,
			top: 10
		});
		
		//bitcoin logo coin
		var logoCoin = Ti.UI.createLabel({
			backgroundImage: "bitcoin_logo.png",
			top: 80,
			width: 120,
			height: 120
		});
		//view1 where is all the names of the items
		var view1 = Ti.UI.createView({
			width: "50%",
			layout : "vertical"
				
		});
		//view2 where is all the current values of the items
		var view2 = Ti.UI.createView({
			width: "50%",
			layout : "vertical"
				
		});
		
		//========================   ITEMS   ==================================
		//high price label
		var lblHighPrice = Ti.UI.createLabel({
			color: 'white',
			//backgroundColor: "yellow",
			font:{fontFamily:'Trebuchet MS',fontSize:18,fontWeight:'bold'},
			 // backgroundGradient: {
        // type: 'linear',
        // startPoint: { x: '0%', y: '50%' },
        // endPoint: { x: '100%', y: '50%' },
        // colors: [ { color: 'red', offset: 0.0}, { color: 'pink', offset: 0.50 }, { color: 'red', offset: 1.0 } ],
    // },
			left: 20,
			text: 'High Price: ',
			top: 80
		});
		// high price value
		var highPrice = Ti.UI.createLabel({
			color: 'white',
			left: 20,
			text: json.ticker.high,
			top: 80
		});
		//low price label
		var lblLowPrice = Ti.UI.createLabel({
			color: 'white',
			left: 20,
			text: 'Low Price: ',
			font:{fontFamily:'Trebuchet MS',fontSize:18,fontWeight:'bold'},
			top: 20
		});
		//low price value
		var lowPrice = Ti.UI.createLabel({
			color: 'white',
			left: 20,
			text: json.ticker.low,
			top: 22
		});
		
		//average label
		var lblAvg = Ti.UI.createLabel({
			color: 'white',
			left: 20,
			text: 'Avergage: ',
			font:{fontFamily:'Trebuchet MS',fontSize:18,fontWeight:'bold'},
			top: 20
		});
		//average value
		var avg = Ti.UI.createLabel({
			color: 'white',
			left: 20,
			text: json.ticker.avg,
			top: 22
		});
		
		var title = Ti.UI.createLabel({
			color: 'white',
			left: 20,
			text: "BTC-E.COM market              BTC - USD" ,
			top: 80
		});
	// add to calendar
		var addText = Ti.UI.createLabel({
			color: 'white',
			left: 20,
			text: "Add To: ",
			top: 75
		});
		
		//button save to calendar
		var btnSave= Ti.UI.createButton({
	backgroundImage: 'Calendar-icon.png',
	title: "",
	font : {fontFamily:"Helvetica",fontsize:100,fontWeight: "bold"},
	color: 'black',
	top: 10,
	width: 50,
	height:50,
	left: 50
	//borderStyle: Ti.UI.INPUT_BORDERSTYLE_ROUNDED,
});
	}
	else {
		// when there is no information to show(for connectivity error or api result null)
		var lblInfo = Ti.UI.createLabel({
			color: 'white',
			text: 'No information found'	
		});
		
		windowInfo.add(lblInfo);
	}
	//exports.showInfo = showInfo;
	windowInfo.add(lblYear);
	windowInfo.add(logoCoin);
	

	
	
	view1.add(lblHighPrice);
	view2.add(highPrice);
	view1.add(lblLowPrice);
	view2.add(lowPrice);
	view1.add(lblAvg);
	view2.add(avg);
	view1.add(title);
	
	view2.add(addText);
	view2.add(btnSave);
	
	
	windowInfo.add(view1);
	windowInfo.add(view2);
	
	
	//scrollView.add(lblHighPrice);
	//scrollView.add(HighPrice);
	//scrollView.add(lblLowPrice);
	windowInfo.open();
	
};


exports.showInfo = showInfo;


//tittleControl: tabs
// get notes from cloud
// function getNotes(){
	// var dbController = require('dbController'); // create instance for database controller
	// var data = dbController.findAll();
	// wowNotes.setData(data);
// 	
// }